    <footer class="py-3 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy;THE NEWS 24.com <?php echo date('Y');?></p>
      </div>
      <!-- /.container -->
    </footer>