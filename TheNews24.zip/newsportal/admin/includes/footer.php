
                <footer class="footer text-right">
                   <?php echo date('Y');?> ©THE NEWS 24.com
                </footer>
