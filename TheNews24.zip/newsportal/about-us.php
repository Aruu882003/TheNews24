<?php
include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>THE NEWS 24 | About us</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/modern-business.css" rel="stylesheet">

<style>
.breadcrumb {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    padding: .75rem 1rem;
    margin-bottom: 0rem;
    list-style: none;
    background-color: #e9ecef;
    border-radius: .25rem;
}

.para-title {
    padding: 20px;
    background: #ce1c00;
    margin-bottom: 50px;
}

.para-title div{
  padding: 10px;
}

.para-title div h2{
    color: #fff;
    text-align: center;
    font-size: 48px;
    font-weight: 600;
}

</style>
  </head>

  <body>

    <!-- Navigation -->
    <?php include('includes/header.php');?>
    <!-- Page Content -->
    <div class="container">

<?php 
$pagetype='aboutus';
$query=mysqli_query($con,"select PageTitle,Description from tblpages where PageName='$pagetype'");
while($row=mysqli_fetch_array($query))
{

?>
    <div style="padding: 20px 10px 15px 10px;">  <h1 class="mt-4 mb-3" style="color: #0b4b8c; font-weight: 700; margin: 15px 0px;"><?php echo htmlentities($row['PageTitle'])?>
   </h1></div>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">About</li>
      </ol>

      <section class="para-title">
				<div >
			<h2 >Who We Are?</h2>	
				</div>
		</section>

      <!-- Intro Content -->
      <div class="row">
        <div class="col-lg-12">
          <p><?php echo $row['Description'];?></p>
        </div>
      </div>
      <!-- /.row -->
<?php } ?>

    </div>
    <!-- /.container -->

    <!-- Footer -->
 <?php include('includes/footer.php');?>


    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>
</html>
